
import java.io.*;
import java.util.Scanner;

public class FileThrowExTester {

    
    public static void main(String[] args) throws IOException {
        int linecounter=0, wordcounter=0, charcounter=0, enterchar=0;
        Scanner in = new Scanner(System.in);
        File file = new File("C:\\Users\\User\\Documents\\NetBeansProjects\\Lab12_1\\text1.txt");
        PrintWriter output = new PrintWriter(file);
        String str = in.nextLine();
        while (!str.equals("quit")) {
            output.println(str);
            str = in.nextLine();
        }
        output.close();
        Scanner out = new Scanner(file);
        while (out.hasNextLine()) {
            linecounter++;
            String[] line = out.nextLine().split(" ");
            wordcounter += line.length;
            enterchar += 2;
        }
        charcounter = (int) file.length()-enterchar;
        System.out.println("Total characters : "+charcounter);
        System.out.println("Total words : "+wordcounter);
        System.out.println("Total lines : "+linecounter);
        
        
    }
    
}
