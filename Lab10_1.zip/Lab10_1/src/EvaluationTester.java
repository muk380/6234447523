
public class EvaluationTester {

    public static void main(String[] args) {
        int sc[] = {45, 48};
        Secretary s = new Secretary("Sasipa", 20000, sc, 60);
        if (s.grade(s.evaluate()) == 'P') {
            System.out.println("Congratulations");
            System.out.println(s);
        }
        else
            System.out.println("Sorry");
        int subjScore[] = {45, 90, 89, 88, 75, 56, 46, 70, 90, 65};
         Subject sj = new Subject("Java", subjScore);
        System.out.println (sj + " Grade class is " +sj.grade(sj.evaluate()));  
    }
}

interface Evaluation {
    double evaluate();
    char grade(double a);
}

class Employee {
    private String name;
    private int salary;
    
    public Employee(String name, int salary) {
        this.name = name;
        this.salary = salary;
    }
    public void setSalary(int salary) {
        this.salary = salary;
    }
    public String toString() {
        return name+"\nsalary = "+salary;
    }
}
class Secretary extends Employee implements Evaluation {
    private int typingSpeed;
    private int[] score;
    
    public Secretary(String name, int salary, int[] score, int typingSpeed){
        super(name,salary);
        this.score = score;
        this.typingSpeed = typingSpeed;
    }
    public double evaluate() {
        int sum=0;
        for (int i=0;i<score.length;i++) {
            sum += score[i];
        }
        return sum;
    }
    public char grade(double a) {
        if (evaluate()>=90) {
            setSalary(18000);
            return 'P';
        }
        else {
            return 'F';
        }
    }
}

class Subject implements Evaluation {
    private String subjName;
    private int[] score;
    
    public Subject(String subjName, int[] score) {
        this.subjName = subjName;
        this.score = score;
    }
    public double evaluate() {
        int sum=0;
        for (int i=0;i<score.length;i++) {
            sum += score[i];
        }
        return sum/(score.length);
    }
    public char grade(double a) {
        if (evaluate()>=70) { 
            return 'P';
        }
        else {
            return 'F';
        }
    }
    public String toString() {
        return subjName;
    }
}