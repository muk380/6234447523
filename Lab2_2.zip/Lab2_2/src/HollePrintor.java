

public class HollePrintor {

    
    public static void main(String[] args) {
        String s1 = "Hello, World!";
        String r1 = s1.replace('o','E');
        String r2 = r1.replace('e','o');
        String r3 = r2.replace('E','e');
        System.out.println(r3);
    }
    
}
