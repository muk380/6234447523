
public class LetterPrinter {
    
    public static void main(String[] args) {
        Letter newletter = new Letter("Jade","Clarissa");
        newletter.addLine("We must find Simon quickly.");
        newletter.addLine("He might be in danger.");
        System.out.println(newletter.getText());
    }
}
