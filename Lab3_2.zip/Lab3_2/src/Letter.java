

public class Letter {

    public String text1;
    public String text2;
    public String text = "";
    
    public Letter(String from, String to){
        text1 = "Dear "+from+":\n\n";
        text2 = "\n"+to;
    }
    public void addLine(String line) {
        text = text+line+"\n";
    }
    public String getText() {
        return text1+text+"\nSincerely,\n"+text2;
    }
}
