package com.example.guessanumber;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Random;

public class StartActivity extends AppCompatActivity {
    Button guessbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);

        Random random = new Random();
        final int number = random.nextInt(100)+1;

        final TextView hinttext = findViewById(R.id.hinttext);
        hinttext.setText("Enter a number (1-100)");

        final EditText edittext = findViewById(R.id.editText);

        guessbtn = findViewById(R.id.guessbtn);
        guessbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int input = Integer.parseInt(edittext.getText().toString());
                if (input<number) {
                    hinttext.setText("Your guess is too low");
                }
                else if (input>number) {
                    hinttext.setText("Your guess is too high");
                }
                else {
                    Intent intent2 = new Intent(getApplicationContext(),EndActivity.class);
                    startActivity(intent2);
                }

            }
        });

    }
}
