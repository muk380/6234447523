
public class Zeller {
    private int dayOfMonth;
    private int month;
    private int year;
    private Day dayOfWeek;
    private int h,m,q,j,k;
    enum Day {
        SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY
    }
    public Zeller(int i1,int i2,int i3) {
        year = i1;
        month = i2;
        dayOfMonth = i3;
        q = dayOfMonth;
        switch (month) {
            case 1:
                m = 13;
                year = year -1;
                break;
            case 2:
                m = 14;
                year = year -1;
                break;
            default:
                m = month;
                break;
        }
        j = (int)year/100;
        k = year%100;
        h = (q + (int)((26*(m+1))/10) + k + (int)k/4 + (int)j/4 + 5*j)%7;
    }
    public Day getDayOfWeek() {
        switch (h) {
            case 0:
                dayOfWeek = Day.SATURDAY;
                break;
            case 1:
                dayOfWeek = Day.SUNDAY;
                break;
            case 2:
                dayOfWeek = Day.MONDAY;
                break;
            case 3:
                dayOfWeek = Day.TUESDAY;
                break;   
            case 4:
                dayOfWeek = Day.WEDNESDAY;
                break;
            case 5:
                dayOfWeek = Day.THURSDAY;
                break;
            case 6:
                dayOfWeek = Day.FRIDAY;
                break;
        }
        return dayOfWeek;
    }
    
}
