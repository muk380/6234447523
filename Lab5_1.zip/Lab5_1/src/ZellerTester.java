
import java.util.Scanner;


public class ZellerTester {
    
    enum Day {
        SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY
    }
    public static void main(String[] args) {
        Scanner input1 = new Scanner(System.in);
        System.out.print("Enter year (e.g., 2012): ");
        int num1 = input1.nextInt();
        Scanner input2 = new Scanner(System.in);
        System.out.print("Enter month (1-12): ");
        int num2 = input2.nextInt();
        Scanner input3 = new Scanner(System.in);
        System.out.print("Enter day of the month (1-31): ");
        int num3 = input3.nextInt();
        Zeller day = new Zeller(num1,num2,num3);
        Zeller.Day n = day.getDayOfWeek();
        System.out.print("Day of the week is ");
        switch (n) {
            case SATURDAY:                
                System.out.println("Saturday");
                break;
            case SUNDAY:                
                System.out.println("Sunday");
                break;
            case MONDAY:                
                System.out.println("Monday");
                break;
            case TUESDAY:
                System.out.println("Tuesday");
                break;   
            case WEDNESDAY:
                System.out.println("Wednesday");
                break;
            case THURSDAY:
                System.out.println("Thursday");
                break;
            case FRIDAY:
                System.out.println("Friday");
                break;
        }
    }
}
