
import java.util.Random;
import java.util.Scanner;


public class Game {
    private int userpoint, comppoint, compinput;
    private String userinput;
    private boolean loop=true;
    
    public void play() {
        userpoint = 0;
        comppoint = 0;
        while (loop) {
            System.out.print("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS: ");
            Scanner enter = new Scanner(System.in);
            userinput = enter.nextLine();
            while (!"0".equals(userinput) && !"1".equals(userinput) && !"2".equals(userinput)) {
            System.out.print("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS: ");
            Scanner intinput = new Scanner(System.in);
            userinput = intinput.nextLine();
            }
            switch(userinput) {
                case "0":
                    System.out.println("You enter: ROCK");
                    break;
                case "1":
                    System.out.println("You enter: PAPER");
                    break;
                case "2":
                    System.out.println("You enter: SCISSORS");
                    break;
            }
            
            Random com = new Random();
            compinput = com.nextInt(3);
            switch(compinput) {
                case 0:
                    System.out.println("Computer: ROCK");
                    break;
                case 1:
                    System.out.println("Computer: PAPER");
                    break;
                case 2:
                    System.out.println("Computer: SCISSORS");
                    break;
            }
            int input = Integer.parseInt(userinput);
            if (input==compinput) {
                System.out.println("It's a tie");
            }
            else if ((compinput==1 && input==0) || (compinput==2 && input==1) || (compinput==0 && input==2)) {
                System.out.println("You lose!");
                comppoint = comppoint+1;
            }
            else {
                System.out.println("You win!");
                userpoint = userpoint+1;
            }
            if (userpoint==comppoint+2) {
                loop = false;
                System.out.println("Congrats! You win!");
            }
            if (comppoint==userpoint+2) {
                loop = false;
                System.out.println("Too bad! You lose.");
            }
        }
        
        System.out.println("User Score: "+userpoint+"\nComputer Score: "+comppoint);
    }
    
    
    
}
