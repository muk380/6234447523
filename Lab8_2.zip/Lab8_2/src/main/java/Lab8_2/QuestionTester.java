
package Lab8_2;
import java.util.ArrayList;
import java.util.Scanner;

public class QuestionTester {

    public static void main(String[] args) {
        Question [] quiz = new Question[4];
        quiz[0] = new Question("Who was the inventor of Java?");
        quiz[0].setAnswer("James Gosling");

        ChoiceQuestion question = new ChoiceQuestion("In which country was the inventor of Java born?");
        question.addChoice("Australia", false);
        question.addChoice("Canada", true);
        question.addChoice("Denmark", false);
        question.addChoice("United States", false);
        quiz[1] = question;
        
        quiz[2] = new NumericQuestion("4.5 - 2.3 = ?");
        quiz[2].setAnswer("2.2");

        FillInQuestion fiQuestion = new FillInQuestion();
        fiQuestion.constructQuestionAndAnswer("The method that returns a string representation for each object is _toString_");
        quiz[3] = fiQuestion;

        Scanner in = new Scanner(System.in);
        for (Question q : quiz) {
            q.display();
            System.out.print("Your answer: ");
            String response = in.nextLine();
            System.out.println(q.checkAnswer(response));
        }
    }
    
}

class Question {
    private String text, answer;
    
    public Question() {
        text="";
    }
    public Question(String text) {
        this.text = text;
    }
    public void setAnswer(String answer) {
        this.answer = answer;
    }
    public void setText(String text) {
        this.text = text;
    }
    public String getText() {
        return text;
    }
    public String getAnswer() {
        return answer;
    }
    public boolean checkAnswer(String response) {
        return response.equals(getAnswer());
    }
    public void display() {
        System.out.println(getText());
    }
}

class NumericQuestion extends Question {
    public NumericQuestion(String text) {
        super(text);
    }
    public boolean checkAnswer(String response) {
        return Double.valueOf(response) <= Double.valueOf(getAnswer())-0.01 &&Double.valueOf(response) >= Double.valueOf(getAnswer())+0.01;
    }
}

class ChoiceQuestion extends Question {
    ArrayList<String> choicelist = new ArrayList<>();
    public ChoiceQuestion(String text) {
        super(text);
    }
    public void addChoice(String choice, boolean correct) {
        choicelist.add(choice);
        if (correct) {
            setAnswer(choice);
        }
    }
    public boolean checkAnswer(String response) {
        return choicelist.get(Integer.parseInt(response)).equals(getAnswer());
    }
    public void display() {
        System.out.println(getText());
        for (int i=0; i<choicelist.size();i++) {
            System.out.println(choicelist.get(i));
        }
    }
}

class FillInQuestion extends Question {
    public FillInQuestion() {
        super();
    }
    public void constructQuestionAndAnswer(String questionText) {
        Scanner parser = new Scanner(questionText);
        parser.useDelimiter("_");
        String question = parser.next();
        String answer = parser.next();
        parser.close();
        question += " ";
        for (int i = 0; i < answer.length(); i++) {
            question += "_ ";
        }
        this.setText(question);
        this.setAnswer(answer);
        } 
    }