
import java.util.ArrayList;


public class BusTester {

    
    public static void main(String[] args) {
        ArrayList<Bus> arr = new ArrayList<Bus>();
        arr.add(new Hybrid(45,1.2,Electric.HIGH_VOLTAGE,150,1));
        arr.add(new CNGBus(50,1,200,2));
        for (int i=0;i<arr.size();i++) {
            System.out.println("ID: "+arr.get(i).getID());
            System.out.println("Emission Tier: "+arr.get(i).getEmissionTier());
            System.out.println("Accel: "+arr.get(i).getAccel());
        }
    }
    
}

interface LiquidFuel {
    double getRange();
    int getEmissionTier();
}

interface Electric {
    double LOW_VOLTAGE=480;
    double HIGH_VOLTAGE=600;
    double getVoltage();
}

abstract class Bus {
    private int ID;
    private int capacity;
    private double cost;
    private static int nextID= 1;
    public Bus(int capacity, double cost) {
        ID= nextID++;
        this.capacity = capacity;
        this.cost = cost;
    }
    public abstract double getAccel();
    public abstract int getEmissionTier();
    public final int getID() {return ID;}
    public int getCapacity() {return capacity;}
    public double getCost() {return cost;}
}   

class CNGBus extends Bus implements LiquidFuel {
    private double range;
    private int emissionTier;
    
    public CNGBus(int capacity, double cost,double range, int emissionTier) {
        super(capacity,cost);
        this.range = range;
        this.emissionTier = emissionTier;
    }
    public double getAccel() {
        return 3.0;
    }
    public double getRange() {
        return range;
    }
    public int getEmissionTier() {
        return emissionTier;
    }
}

class Hybrid extends Bus implements LiquidFuel, Electric {
    private double voltage, range;
    private int emissionTier;
    
    public Hybrid(int capacity, double cost, double voltage, double range, int emissionTier) {
        super(capacity,cost);
        this.range = range;
        this.emissionTier = emissionTier;
        if (voltage<Electric.LOW_VOLTAGE) {
            this.voltage = Electric.LOW_VOLTAGE;
        }
        else if (voltage>Electric.HIGH_VOLTAGE) {
            this.voltage = Electric.HIGH_VOLTAGE;
        }
        else {
            this.voltage = voltage;
        }
    }
    public double getRange() {
        return range;
    }
    public int getEmissionTier() {
        return emissionTier;
    }
    public double getVoltage() {
        return voltage;
    }
    public double getAccel() {
        return 4.0;
    }
}