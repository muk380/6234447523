
public class TimeInterval {
    private int starthour;
    private int startmin;
    private int endhour;
    private int endmin;
    private int hour;
    private int min;
    
    public TimeInterval(int start, int end) {
        starthour = (int)start/100;
        startmin = start%100;
        endhour = (int)end/100;
        endmin = end%100;
        if (endmin>=startmin){
            min = endmin - startmin;
            hour = endhour - starthour;
        }
        else {
            min = (endmin+60) - startmin;
            hour = endhour - 1 - starthour;
        }
    }
    
    public int getHours() {
        return hour;
    }
    public int getMinutes() {
        return min;
    }
}
