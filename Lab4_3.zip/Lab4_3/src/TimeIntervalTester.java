
import java.util.Scanner;

public class TimeIntervalTester {
    
    public static void main(String[] args) {
        Scanner input1 = new Scanner(System.in);
        System.out.print("Enter start time: ");
        int num1 = input1.nextInt();
        Scanner input2 = new Scanner(System.in);
        System.out.print("Enter start time: ");
        int num2 = input2.nextInt();
        TimeInterval time = new TimeInterval(num1 ,num2);
        System.out.print(time.getHours()+" hours ");
        System.out.println(time.getMinutes()+" minutes");
    }
}
