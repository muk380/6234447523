
public class DigitExtractor {
    private int lastdigit;
    private int number;
    
    public DigitExtractor(int anInteger) {
        number = anInteger;
    }
    public int nextDigit() {
        lastdigit = number%10;
        number = (int)number/10;
        return lastdigit;
        
    }

}
