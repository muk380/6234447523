
public class CannonBallTester {

    
    public static void main(String[] args) {
        CannonBall ball = new CannonBall(100); 
        ball.simulatedFlight();
        System.out.print("Final distance: ");
        System.out.printf("%.3f",ball.getSimulatedDistance());
        System.out.print(" Total time: ");
        System.out.printf("%.2f",ball.getSimulatedTime());
        System.out.println();
        System.out.print("Distance from calculus equation: ");
        System.out.printf("%.3f",ball.calculusFlight(ball.getSimulatedTime()));
        System.out.println();
    }
    
}
