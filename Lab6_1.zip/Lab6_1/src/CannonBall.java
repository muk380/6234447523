
public class CannonBall {
    private double initV; 
    private final double firstV;
    private double simS; 
    private double simT; 
    public static final double g = 9.81;
    
    public CannonBall(double a) {
        initV = a;
        firstV = a;
    }
    public void simulatedFlight() {
       int c = 0;
        while (initV>0) {
            simT = simT + 0.01;
            simS = simS + initV*0.01;
            initV = initV - g*0.01;
            c = c+1;
            if (c%100==0) {
                System.out.print("Distance on "+c/100+" sec: ");
                System.out.printf("%.3f", simS);
                System.out.println();
            }
        }
    } 
    public double calculusFlight(double t) {
        return (-0.5)*g*t*t+firstV*t;
    }
    public double getSimulatedTime(){
        return simT;
    }
    public double getSimulatedDistance() {
        return simS;
    }
}
