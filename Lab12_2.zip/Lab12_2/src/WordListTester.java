
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;


public class WordListTester {

    
    public static void main(String[] args) {
        ArrayList<String> wordlist = new ArrayList<String>();
        ArrayList<String> notcontain = new ArrayList<String>();
        try {
            File file = new File("wordlist.txt");
            Scanner in = new Scanner(file);
            String str = in.nextLine();
            while (in.hasNextLine()) {
                wordlist.add(str);
                str = in.nextLine();
            }
        }
        catch (FileNotFoundException e) {
            System.out.println(e);
        }
        Scanner in = new Scanner(System.in);
        System.out.print("Enter a sentence: ");
        String[] words = in.nextLine().split(" ");
        for (int i=0;i<words.length;i++) {
            notcontain.add(words[i]);
            for (int j=0;j<wordlist.size();j++) {
                if  (words[i].equals(wordlist.get(j)))  {
                    notcontain.remove(words[i]);
                    break;
                }
            }
        }
        System.out.println("Words not contained:");
        if (!notcontain.isEmpty()) {
            for (int i=0;i<notcontain.size();i++) {
                System.out.println(notcontain.get(i));
            }
        } else {
            System.out.println("N/A");
        }

    }
    
}
