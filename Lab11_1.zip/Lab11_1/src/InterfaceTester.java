
import java.util.ArrayList;


public class InterfaceTester {
    public static void main(String[] args) {
        MusicBox m = new MusicBox();
        m.enqueue("ออเจ้าเอย");
        m.enqueue("เธอหนอเธอ");
        m.enqueue("เพียงสบตา");
        m.enqueue("บุพเพสันนิวาส");
        m.dequeue();
        m.dequeue();
        m.dequeue();
        m.dequeue();
        SelfCheckOut s = new SelfCheckOut();
        s.enqueue(new Product("Pen", 25));
        s.enqueue(new Product("Pencil", 10));
        s.enqueue(new Product("Ruler", 20));
        s.enqueue(new Product("Eraser", 15));
        s.enqueue(new Product("Pencil Box", 30));
        s.dequeue();
        s.dequeue();
        s.dequeue();
        s.dequeue();
        s.dequeue();
        System.out.println("Total amount = " + s.getAmount());
    }
}

interface SimpleQueue {
    void enqueue(Object o);
    void dequeue();
}

class Product {
    private String name;
    private double price;
    public Product(String n, double p) {
        name = n;
        price = p;
    }
    public String getName() {
        return name;
    }
    public double getPrice() {
        return price;
    }
}

class MusicBox implements SimpleQueue {
    private ArrayList<Object> queue = new ArrayList<Object>();
    public void enqueue(Object o) {
        queue.add(o);
        System.out.println(o.toString()+" is added in queue");
    }
    public void dequeue() {
        System.out.println("Now playing "+queue.get(0));
        queue.remove(0);
    }
}

class SelfCheckOut implements SimpleQueue {
    private double amount;
    private ArrayList<Object> queue = new ArrayList<Object>();
    public void enqueue(Object o) {
        queue.add(o);
        System.out.println(((Product)o).getName()+" is added in queue");
    }
    public void dequeue() {
        if (queue.get(0) instanceof Product) {
            amount += ((Product)queue.get(0)).getPrice();
        }
        queue.remove(0);
    }
    public double getAmount() {
        return amount;
    }
}