
public class CashRegister {
    private double balance;
    private double payment;
    private double purchase;
    private final double tax;
    private double totaltax;

    public CashRegister(double rate) {
        tax = rate;
    }
    public void RecordPurchase(double price) {
        payment = payment + price;
    }
    public void RacordTaxablePurchase(double price) {
        purchase = price*(100+tax)/100;
        payment = payment + purchase;
        totaltax = totaltax + price*tax/100;
    }
    public double getTotalTax() {
        return totaltax;
    }
    public void enterPayment(double cash) {  
        balance = balance + cash;
    }
    public double giveChange() {
        balance = balance - payment;
        purchase = 0;
        payment = 0;
        return balance;
    }
}
