
public class CashRegisterTester {
    
    public static void main(String[] args) {
        CashRegister order = new CashRegister(7);
        order.RecordPurchase(50);
        order.RecordPurchase(10);
        order.RacordTaxablePurchase(20);
        order.enterPayment(100);
        System.out.println("Your change is "+(float)order.giveChange());
    }
}
