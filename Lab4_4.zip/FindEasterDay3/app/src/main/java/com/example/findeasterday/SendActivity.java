package com.example.findeasterday;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class SendActivity extends AppCompatActivity {
    String strmon;
    int day;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send);
        TextView textView = findViewById(R.id.textView);

        day = getIntent().getExtras().getInt("day");
        strmon = getIntent().getExtras().getString("mon");
        textView.setText(day+" "+strmon);
    }
}
