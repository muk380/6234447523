package com.example.findeasterday;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class MainActivity extends AppCompatActivity {
    public Button button;
    public int y, a, b, c, d, e, g, h, j, k, m, r, n, p;
    private String month;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        final EditText edittext1 = findViewById(R.id.editText);
        Button button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a = y%19;
                b = (int)y/100;
                c = y%100;
                d = (int)b/4;
                e = b%4;
                g = (int)(8*b + 13)/25;
                h = (int)(19*a+b-d-g+15)/30;
                j = (int)c/4;
                k = c%4;
                m = (int)(a+11*h)/319;
                r = (2*e+2*j-k-h+m+32)%7;
                n = (int)(h-m+r+90)/25;
                p = (h-m+r+n+19)%32;
                if (n==1)
                    month = "January";
                if (n==2)
                    month = "February";
                if (n==3)
                    month = "March";
                if (n==4)
                    month = "April";
                if (n==5)
                    month = "May";
                if (n==6)
                    month = "June";
                if (n==7)
                    month = "July";
                if (n==8)
                    month = "August";
                if (n==9)
                    month = "September";
                if (n==10)
                    month = "October";
                if (n==11)
                    month = "November";
                if (n==12)
                    month = "December";
            }
        });
        button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(getApplicationContext(),SendActivity.class);
                intent1.putExtra("day", p);
                intent1.putExtra("mon", month);
                startActivity(intent1);
            }
        });
    }
}
