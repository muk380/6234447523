
import java.util.ArrayList;
import java.io.*;
import java.util.Scanner;


public class FileMatch {

    
    public static void main(String[] args) {
        ArrayList<AccountRecord> acctdata = new ArrayList<AccountRecord>();
        ArrayList<TransactionRecord> transdata = new ArrayList<TransactionRecord>();
        
        try (
                Scanner acctlist = new Scanner(new File("master.txt"));
                Scanner translist = new Scanner(new File ("trans.txt")); 
            ){
            while (acctlist.hasNextLine()) {
                Scanner line = new Scanner(acctlist.nextLine());
                acctdata.add(new AccountRecord(Integer.parseInt(line.next()),line.next() + " " +line.next(),Double.parseDouble(line.next())));
            }
            while (translist.hasNextLine()) {
                Scanner line = new Scanner(translist.nextLine());
                transdata.add(new TransactionRecord(Integer.parseInt(line.next()),Double.parseDouble(line.next())));
            }
            for (AccountRecord a : acctdata) {
                for (TransactionRecord t : transdata) {
                    a.combine(t);
                }
            }
        }
        catch (IOException e) {
            System.out.print(e);
        }
        try (RandomAccessFile r = new RandomAccessFile("newMaster.dat","rw")){
            for (AccountRecord a : acctdata) {
                r.writeInt(a.getAcctNo());
                r.writeChar(' ');
                r.writeChars(a.getName());
                for(int i=0;i<30-(a.getName()).length();i++){
                    r.writeChar(' ');
                }
                r.writeChar(' ');
                r.writeDouble(a.getBalance());
                r.writeChar(' ');
                r.writeInt(a.getTransCnt());
                r.writeChars("\n");
            } 
        } catch (IOException e){
            System.out.println(e);
        }
        try (RandomAccessFile r = new RandomAccessFile("newMaster.dat","rw")){
            int line=0, count=0;
            double sum=0;
            while(r.readLine()!=null)
                line++;
            for (int i=0;i<line;i++){
                r.seek(getPointerBalance(i));
                sum += r.readDouble();
                r.seek(getPointerTransaction(i));
                if (r.readInt()==0){
                    count++;
                }
            }
            System.out.println("Total Account Record : "+line);
            System.out.println("Total balance : "+sum);
            System.out.println("No transaction : "+count+" account.");
        } catch(IOException e){
            System.out.println(e);
        }
    }
    
    public static int getPointerTransaction(int line){
        return 78+(line*84);
    }
    
    public static int getPointerBalance(int line){
        return 68+(line*84);
    }
    
}

class AccountRecord {
    private int acctNo;
    private String name;
    private double balance;
    private int transCnt = 0; // นับว่า บัญชีนี ้ท ารายการ transaction ไปกี่ครั้ง
    public AccountRecord (int acctNo, String name, double balance) {
        this.acctNo = acctNo;
        this.name = name;
        this.balance = balance;
    }
    public int getAcctNo() { return acctNo; }
    public String getName() { return name; }
    public double getBalance(){ return balance; }
    public int getTransCnt() { return transCnt; }
    public void combine(TransactionRecord t) {
        if (t.getAccountNumber()==acctNo) {
            balance += t.getTransAmount();
            transCnt++;
        }
    }
}

class TransactionRecord {
    private int accountnum;
    private double transamount;
    public TransactionRecord(int accountnum, double transamount) {
        this.accountnum = accountnum;
        this.transamount = transamount;
    }
    public int getAccountNumber() {
        return accountnum;
    }
    public double getTransAmount() {
        return transamount;
    }
    public void setTransAmount(double transamount) {
        this.transamount = transamount;
    }
}

