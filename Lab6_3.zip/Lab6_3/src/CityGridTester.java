
public class CityGridTester {

    
    public static void main(String[] args) {
        double sum=0;
        int maxcount=0;
        CityGrid city = new CityGrid(10,10);
        for (int i=0; i<10000 ; i++) {
            int footcount=0;
            while (footcount<1000 && city.isInCity()) {
                city.walk();
                footcount++;
            }
            sum=sum+footcount;
            if (footcount>=maxcount) {
                maxcount=footcount;
            }
            city.reset();
        }
        System.out.print("Average number of steps that a person can take and is still in the city: ");
        System.out.printf("%.2f",sum/10000);
        System.out.println("\nMaximum number of steps that a person can take and is still in the city: "+maxcount);
    }
    
}
