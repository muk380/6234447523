
import java.util.Random;


public class CityGrid {
    private int xCoor; 
    private int yCoor;
    private int xmax;
    private int ymax; 
    
    public CityGrid(int a, int b) {
        xmax = a;
        ymax = b;
        xCoor = (int)a/2;
        yCoor = (int)b/2;
    }
    public void walk() {
        Random walk = new Random();
        int move = walk.nextInt(4);
        switch (move) {
            case 0:
                xCoor--;
                break;
            case 1:
                xCoor++;
                break;
            case 2:
                yCoor--;
                break;
            case 3:
                yCoor++;
                break; 
        }
    }
    public boolean isInCity(){
        boolean incity = xCoor<=xmax && yCoor<=ymax;
        return incity;
    }
    public void reset() {
        xCoor = (int)xmax/2;
        yCoor = (int)ymax/2;
    }
}
