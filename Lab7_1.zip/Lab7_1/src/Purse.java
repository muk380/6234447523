
import java.util.ArrayList;
import java.util.HashMap;


public class Purse {
    ArrayList<String> purse = new ArrayList<String>();
    
    public void addCoin(String coinName) {
        purse.add(coinName);
    }
    public String toString() {
        //System.out.println("Purse"+purse);
        String returnpurse = "Purse"+purse;
        return returnpurse;
    }
    public ArrayList<String> reverse() {
        ArrayList<String> newpurse = new ArrayList<String>();
        for (int i=purse.size()-1;i>=0;i--) {
            newpurse.add(purse.get(i));
        }
        return newpurse;
    }
    public void transfer(Purse other) {
        while (!purse.isEmpty()) {
            other.addCoin(purse.get(0));
            purse.remove(0);
        }
    }
    public boolean sameContents(Purse other) {
        boolean same = false;
        if (other.purse.size()==purse.size()) {
            for (int i=0;i<purse.size();i++) {
                if (purse.get(i).equals(other.purse.get(i))) {
                    same=true;
                }
                else {
                    same=false;
                    break;
                }
            }
        }
        return same;
    }
    public boolean sameCoins(Purse other) {
        HashMap<String, Integer> dict1 = new HashMap();
        for (int i=0;i<purse.size();i++) {
            if (dict1.containsKey(purse.get(i))) {
                dict1.replace(purse.get(i), dict1.get(purse.get(i))+1);
            }
            else {
                dict1.put(purse.get(i), 1);
            }
        }
        HashMap<String, Integer> dict2 = new HashMap();
        for (int n=0;n<other.purse.size();n++) {
            if (dict2.containsKey(other.purse.get(n))) {
                dict2.replace(other.purse.get(n), dict2.get(other.purse.get(n))+1);
            }
            else {
                dict2.put(other.purse.get(n), 1);
            }
        }
        return dict1.equals(dict2);
    }
    
}
