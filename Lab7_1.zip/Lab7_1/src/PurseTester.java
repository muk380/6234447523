
public class PurseTester {

    
    public static void main(String[] args) {
        Purse purse = new Purse();
        purse.addCoin("Quarter");
        purse.addCoin("Dime");
        purse.addCoin("Nickel");
        purse.addCoin("Dime");
        System.out.println("Print purse");
        System.out.println(purse.toString());
        System.out.println("Print reversed purse");
        System.out.println("Purse"+purse.reverse());
        
        Purse a = new Purse();
        a.addCoin("Quarter");
        a.addCoin("Dime");
        a.addCoin("Nickel");
        a.addCoin("Dime");
        System.out.println("Print purse a");
        System.out.println(a);
        Purse b = new Purse();
        b.addCoin("Dime");
        b.addCoin("Nickel");
        System.out.println("Print purse b");
        System.out.println(b);
        a.transfer(b);
        System.out.println("Print purse a and purse b after a.transfer(b)");
        System.out.println(a);
        System.out.println(b);
        
        Purse testpurse = new Purse();
        testpurse.addCoin("Quarter");
        testpurse.addCoin("Dime");
        testpurse.addCoin("Dime");
        testpurse.addCoin("Nickel");
        System.out.println("Print testpurse");
        System.out.println(testpurse);
        System.out.println("Print purse");
        System.out.println(purse);
        System.out.println("Print sameContents (should be false)");
        System.out.println(purse.sameContents(testpurse));
        System.out.println("Print sameCoins (should be true)");
        System.out.println(purse.sameCoins(testpurse));
        
    }
    
}
