
package Lab8_1;


public class CarTester {

    public static void main(String[] args) {
        Car myCar = new Car(50, 20); // 20 miles per gallon
        myCar.addGas(20); // add into tank 20 gallons
        myCar.drive(100); // drive 100 miles (use 5 gallons)
        System.out.println("Gas left = " + myCar.getGas() + " gallons");
        Truck t = new Truck(50, 20, 15, 20);
        t.drive(100);
        System.out.println("Gas left = " + t.getGas() + " gallons");
        Truck t2 = new Truck(0, 20, 20, 15);
        t2.addGas(5);
        t2.drive(100);
        System.out.println("Gas left = " + t2.getGas() + " gallons");

    }
}

class Car {
    protected double gas;
    protected final double efficiency;
    
    public Car(double gas, double efficiency) {
        this.gas=gas;
        this.efficiency=efficiency;
    }
    public void drive(double distance) {
        double usage = distance/efficiency;
        if (usage<=gas) {
            gas = gas-usage;
        }
        else {
            System.out.println("You cannot drive too far, please add gas");
        }
    } 
    public void setGas(double amount) {
        gas = amount;
    }
    public double getGas() {
        return gas;
    }
    public double getEfficiency() {
        return efficiency;
    }
    public void addGas(double amount) {
        gas = gas+amount;
    }
}
class Truck extends Car {
    private final double M_weight;
    private double weight;
    public Truck(double gas, double efficiency, double M_weight, double weight) {
        super(gas,efficiency);
        this.M_weight = M_weight;
        this.weight = weight;
        if (this.M_weight>this.weight) {
            this.weight = M_weight;
        }
    }
    public void drive(double distance) {
        double usage;
        if (weight<1) {
            usage = distance/efficiency;
        }
        else if (weight>1 && weight<=10) {
            usage = distance/efficiency*1.1;
        }
        else if (weight>10 && weight<=20) {
            usage = distance/efficiency*1.2;
        }
        else {
            usage = distance/efficiency*1.3;
        }
        if (usage<=gas) {
            gas = gas-usage;
        }
        else {
            System.out.println("You cannot drive too far, please add gas");
        }
    }
}
