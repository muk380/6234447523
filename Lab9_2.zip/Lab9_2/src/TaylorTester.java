
public class TaylorTester {

    public static void main(String[] args) {
        expo exp = new expo(7, 1);
        exp.printValue();
        sine s = new sine(7, Math.PI/4);
        s.printValue();
        cosine cs = new cosine(7, 1);
        cs.printValue();
    }
}

abstract class Taylor {
    int k;
    double x;
    public abstract void printValue();
    public abstract double getApprox();
    
    public int factorial(int n) {
        int fac = 1;
        for (int i=1;i<=n;i++) {
            fac = fac*i;
        }
        return fac;
    }
    public void setIter(int k) {
        this.k = k;
    }
    public int getIter() {
        return k;
    }
    public void setValue(double x) {
        this.x = x;
    }
    public double getValue() {
        return x;
    }
}

class expo extends Taylor {
    public expo(int k, double x) {
        setIter(k);
        setValue(x);
    }
    public double getApprox() {
        double sum=0;
        for (int i=0;i<=k;i++) {
            sum += Math.pow(x, i)/factorial(i);
        }
        return sum;
    }
    public void printValue() {
        System.out.println("Value from Math.exp() is "+Math.exp(getValue())+".");
        System.out.println("Approximated value is "+getApprox()+".");
    }
}
class sine extends Taylor {
    public sine(int k, double x) {
        setIter(k);
        setValue(x);
    }
    public double getApprox() {
        double sum=0;
        for (int i=0;i<=k;i++) {
            sum += Math.pow(-1, i)*Math.pow(x, 2*i+1)/factorial(2*i+1);
        }
        return sum;
    }
    public void printValue() {
        System.out.println("Value from Math.sin() is "+Math.sin(getValue())+".");
        System.out.println("Approximated value is "+getApprox()+".");
    }
}
class cosine extends Taylor {
    public cosine(int k, double x) {
        setIter(k);
        setValue(x);
    }
    public double getApprox() {
        double sum=0;
        for (int i=0;i<=k;i++) {
            sum += Math.pow(-1, i)*Math.pow(x, 2*i)/factorial(2*i);
        }
        return sum;
    }
    public void printValue() {
        System.out.println("Value from Math.cos() is "+Math.cos(getValue())+".");
        System.out.println("Approximated value is "+getApprox()+".");
    }
}