
public class MagicSquare {
    private int i, j;
    private String[][] board;
    public MagicSquare(int n) {
        board = new String[n][n];
        i=n;
        j=(int)n/2+1;
        board[i][j] = String.valueOf(1);
        for (int k=2;k<=n*n;k++) {
            i++;
            j++;
            if (board[i+1][j+1]!=null || ((i==n)&&j==n)) {
                i--;
            }
            else if (i==n) {
                i=0;
            }
            else if (j==n) {
                j=0;
            }
            board[i][j] = String.valueOf(k);
        }
    }
    public String toString() {
        String returnstring="";
        for (int a=1;a<board.length;a++) {
            for (int b=1;b<board[0].length;b++) {
                returnstring = returnstring+board[a][b]+" ";
            }
            returnstring = returnstring+"\n";
        }
        return returnstring;
    }
}
